using Godot;
using System;

[GlobalClass]
public partial class BlockState : Resource
{
    /// <summary>
    /// 所代表区块的坐标
    /// </summary>
    public Vector2I BlockPosition { get; set; } = new Vector2I(0, 0);

    const int a = 2;
    
    public BlockState() { }
    public BlockState(int block_x,int block_y) : this(new Vector2I(block_x, block_y))
    {
        return;
    }

    public BlockState(Vector2I blockPosition)
    {
        this.BlockPosition = blockPosition;
    }
}
