##区块状态机仅聚焦结果节点(result_node)间的变化，而结果节点(result_node)内部的操作则不受理
class_name BlockLoadStateMachine_introduce
extends Object

#region 基本操作


##区块加载状态机的模版，相关信息详见[member load_state_information]
static var load_state_information_template:Dictionary[StringName,Array]={
&"enter":[{&"not_in_memory":true},0,Callable()],##进入状态机
&"exit":[{},20,Callable()],##移除出状态机
&"not_in_memory":[{&"loading_in_memory":true,&"reading_information":true,&"reading_information_in_thread":true},0,Callable()],##不存在于内存
&"loading_in_memory":[{&"load_in_memory":true},0,Callable()],##正在加载于内存
&"reading_information":[{&"loading_in_memory":true},0,Callable()],##正在读取信息
&"reading_information_in_thread":[{&"loading_in_memory":true},0,Callable()],##正在线程读取信息
&"load_in_memory":[{&"deleting_from_memory":true,&"saving_information":true,&"saving_information_in_thread":true,&"loading_in_game":true},0,Callable()],##仅加载于内存
&"deleting_from_memory":[{&"not_in_memory":true},0,Callable()],##正在删除出内存
&"saving_information":[{&"deleting_from_memory":true},0,Callable()],##正在保存信息
&"saving_information_in_thread":[{&"deleting_from_memory":true},0,Callable()],##正在线程保存信息
&"loading_in_game":[{&"load_in_game":true},0,Callable()],##正在加载于游戏
&"load_in_game":[{&"deleting_from_game":true},0,Callable()],##加载于游戏
&"deleting_from_game":[{&"load_in_memory":true},0,Callable()],##正在卸载于游戏
}

##区块加载状态机的信息储存字典，每个键值对都储存着一个节点的信息[br]
##键为[StringName]格式的状态机节点名称，值为[Array]类型的数组，[br]
##索引0为导向的节点名称组成的[Dictionary]类型字典，值代表是否允许导向[br]
##索引1为[int]类型的该节点的优先度[br]
##索引2为[Callable]类型代表变化到该节点时调用的函数[br]
var load_state_information:Dictionary[StringName,Array]=load_state_information_template



##判断该区块加载状态机是否有[code]node_name[/code]对应名称的节点存在
func has_node(node_name:StringName) -> bool :
	if not load_state_information.has(node_name): return false
	return true

##获取该区块加载状态机[code]node_name[/code]对应名称的节点所导向的节点，[br]
##若不存在该节点则返回空字典，[br]
##根据[code]need_check_existence[/code]参数判断是否需要检测节点存在[br]
func get_oriented_nodes(node_name:StringName,need_check_existence:bool=true) -> PackedStringArray :
	if need_check_existence:
		if not load_state_information.has(node_name): return []
	return load_state_information[node_name][0]

##获取模版区块加载状态机[code]node_name[/code]对应名称的节点所导向的节点，[br]
static func get_template_oriented_nodes(node_name:StringName,need_check_existence:bool=true) -> Dictionary[StringName,bool] :
	if need_check_existence:
		if not load_state_information_template.has(node_name): return {}
	return load_state_information_template[node_name][0]


##获取该区块加载状态机内[code]node_name[/code]对应名称的节点其优先度为[code]node_priority[/code]，[br]
##若不存在该节点则返回-2^63，[br]
##根据[code]need_check_existence[/code]参数判断是否需要检测节点存在[br]
func get_node_priority(node_name:StringName,need_check_existence:bool=true) -> int :
	if need_check_existence:
		if not has_node(node_name): return -2^63
	return load_state_information[node_name][1]

##设置该区块加载状态机内[code]node_name[/code]对应名称的节点其优先度为[code]node_priority[/code]，[br]
##根据[code]need_check_existence[/code]参数判断是否需要检测节点存在[br]
func set_node_priority(node_name:StringName,node_priority:int=0,need_check_existence:bool=true) -> bool :
	if need_check_existence:
		if not has_node(node_name): return false
	load_state_information[node_name][1]=node_priority
	return true
#endregion


#region 路径相关


##储存所有结果节点的[PackedStringArray]类型数组
const result_nodes_list:PackedStringArray=["not_in_memory","load_in_memory","load_in_game"]

##储存所有结果节点的[Dictionary[StringName,bool]]类型字典
const result_nodes_dict:Dictionary[StringName,bool]={&"not_in_memory":true,&"load_in_memory":true,&"load_in_game":true}

##模版节点所组成的路径及用[Dictionary]储存的路径下的节点
static var template_paths_nodes:Dictionary[StringName,Dictionary]={}

##模版节点所属的路径，路径名称以[Dictionary]类型储存
static var template_nodes_associated_paths:Dictionary[StringName,Dictionary]={}

##初始化[member template_paths_nodes]与[member template_nodes_associated_paths]
static func initialize_result_nodes_paths() -> bool :
	for template_node_name in load_state_information_template:#进行所有节点统一的初始化操作
		load_state_information_template[template_node_name][0]=Dictionary(load_state_information_template[template_node_name][0],TYPE_STRING_NAME,&"",null,TYPE_BOOL,&"",null)#将所有节点导向节点的集合转换为指定格式
		template_nodes_associated_paths[template_node_name]=Dictionary({},TYPE_STRING_NAME,&"",null,TYPE_BOOL,&"",null)#为每个节点所属的路径信息设定为空
	for result_node_index in result_nodes_list.size():#为每个结果节点生成对应的路径
		var result_node_name:StringName=result_nodes_list[result_node_index]#
		var path_nodes_names_list:PackedStringArray=get_template_oriented_nodes(result_node_name).keys()#储存目标路径上每次遍历获取的节点名称，初始值为该结果节点所导向的节点数组
		var path_nodes_parent_indexs:PackedInt32Array=[]#储存每个遍历到的节点其前一个连接的节点的索引
		path_nodes_parent_indexs.resize(path_nodes_names_list.size())
		path_nodes_parent_indexs.fill(-1)
		var final_result_nodes_indexs:PackedInt32Array=[]#储存每个最终导向的结果节点在path_nodes_parent_indexs这条多向路径中的索引
		var now_iteration_size:int=0#在新一次遍历前更新路径节点集合的大小
		var last_iteration_size:int=0#获取前一次路径节点集合的大小
		while true:#获取两个结果节点之间数组形式的连接路径
			now_iteration_size=path_nodes_names_list.size()
			if now_iteration_size==last_iteration_size: break#若未有新节点被获取，则认定为路径上的节点已全部被遍历，结束循环
			for traversing_node_number in now_iteration_size-last_iteration_size:#为获取新节点所导向的新节点
				var traversing_node_index:int=last_iteration_size+traversing_node_number
				var traversing_node_name:String=path_nodes_names_list[traversing_node_index]
				if result_nodes_dict.has(traversing_node_name):#若遍历到了另一个结果节点
					final_result_nodes_indexs.append(traversing_node_index)#则将视其为路径的终点进行标注
					continue
				var new_nodes_names:PackedStringArray=get_template_oriented_nodes(traversing_node_name).keys()
				path_nodes_names_list.append_array(new_nodes_names)
				#region 更新对应索引
				var ago_path_nodes_parent_indexs_size:int=path_nodes_parent_indexs.size()
				path_nodes_parent_indexs.resize(ago_path_nodes_parent_indexs_size+new_nodes_names.size())
				for new_node_number in new_nodes_names.size():
					path_nodes_parent_indexs[ago_path_nodes_parent_indexs_size+new_node_number]=traversing_node_index
				#endregion
			last_iteration_size=now_iteration_size
		for final_result_node_index in final_result_nodes_indexs:#从每个作为终点的结果节点出发，再次反向构建这条路径，并存入对应信息
			var path_name:StringName=StringName("%s_to_%s")%[result_node_name,path_nodes_names_list[final_result_node_index]]
			if not template_paths_nodes.has(path_name):#若路径不存在则初始化该路径
				template_paths_nodes[path_name]={}
			var target_node_index:int=final_result_node_index
			var target_node_name:StringName=&""
			for _step in final_result_node_index+1:#仅循环final_result_node_index次数
				target_node_index=path_nodes_parent_indexs[target_node_index]#更新其在路径上对应的前一个节点的索引
				if target_node_index==-1: break#若索引更新到了起点则结束循环
				target_node_name=path_nodes_names_list[target_node_index]#更新其的节点名称
				template_paths_nodes[path_name][target_node_name]=true
				template_nodes_associated_paths[target_node_name][path_name]=true
	return true

static func _init() -> void :
	initialize_result_nodes_paths()
	return


#endregion


#region 状态变化


##目前选中的节点
var selected_node_name:StringName=&"enter"

##是否锁定选中的节点即禁止状态节点的变化
var is_lock_selected_node:bool=false



##根据状态变化
func change_next_node() -> bool :
	return false



#endregion
