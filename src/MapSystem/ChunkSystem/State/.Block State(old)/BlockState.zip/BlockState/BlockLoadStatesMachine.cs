using Godot;
using System;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Dynamic;
using System.Runtime.CompilerServices;
using System.Data.Common;





/// <summary>
/// 区块加载状态机,提供表示与更迭加载状态的功能
/// </summary>
[GlobalClass]
public partial class BlockLoadStatesMachine : BlockState
{

	/// <summary>
	/// 区块加载状态机的节点信息储存字典
	/// </summary>
	public static Dictionary<string, BlockStatesNodeInfo> BlockLoadNodesInformation { get; set; } = null;


	/// <summary>
	/// 储存结果节点及其导向节点信息的集合
	/// </summary>
	public static Dictionary<string, NodesPathOfResultNodePath> ResultNodesInformation { get; set; } = null;

	/// <summary>
	/// 储存结果节点间的路径
	/// </summary>
	public static Dictionary<string,Dictionary<string,Dictionary<string,ushort>>> ResultNodesToOtherPaths { get; set; } = null;



	/// <summary>
	/// 储存<see cref="BlockLoadNodesInformation"/>相关设置的文件路径
	/// </summary>
	public static string MachineNodesFilePath { get; } = ProjectSettings.GlobalizePath("res://Map System/Block State/BlockStatesManchineNodes.json");


	/// <summary>
	/// 表示在<see cref="BlockLoadNodesInformation"/>中的值数组不同信息类型代表的索引
	/// </summary>
	public enum NodePriorityIndex : int
	{
		OrientedNodesMap = 0,
		NodePriority = 1,
		OrientedMethodCode = 2,
		IsResultNode = 3,
		NodeIntroduce = 4,
		Size = 5
	}


	/// <summary>
	/// 获取指定节点其BlockStatesNodeInfo类型的信息
	/// </summary>
	/// <param name="nodeName">目标节点的名称</param>
	/// <returns></returns>
	static BlockStatesNodeInfo? GetNodeInfo(string nodeName)
	{
		if (BlockLoadNodesInformation.ContainsKey(nodeName) == false)
			return null;
		return BlockLoadNodesInformation[nodeName];
	}

	/// <summary>
	/// 获取指定结果节点相关路径其ResultNodePath类型的信息
	/// </summary>
	/// <param name="nodeName">目标结果节点的名称</param>
	/// <returns></returns>
	static NodesPathOfResultNodePath? GetResultNodePathInfo(string resultNodeName)
	{
		if (ResultNodesInformation.ContainsKey(resultNodeName) == false)
			return null;
		return ResultNodesInformation[resultNodeName];
	}

	static Dictionary<string,ushort> GetResultNodeToAnotherPath(string startResultNodeName,string targetResultNodeName)
	{
		if (ResultNodesToOtherPaths.ContainsKey(startResultNodeName)==false)
			return null;
		Dictionary<string,Dictionary<string,ushort>> startResultNodeInfo = ResultNodesToOtherPaths[startResultNodeName];
		if (startResultNodeInfo.ContainsKey(targetResultNodeName)==false)
			return null;
		return startResultNodeInfo[targetResultNodeName];
	}


	/*******************************
			   节点信息初始化
	********************************/


	/// <summary>
	/// 初始化所有的节点信息以及结果节点的路径信息
	/// </summary>
	static BlockLoadStatesMachine()
	{
		if (InitializeNodesInformation() == false)
		{
			GD.PushError("在初始化BlockLoadStatesMachine时,在初始化状态节点信息时发生了错误,请进行检查,这至关重要");
			return;
		}
		foreach (string startResultNodeName in ResultNodesInformation.Keys)//将每个结果节点数据设置于全局的数据库中
		{
			NodesPathOfResultNodePath? getPathResult = FindNodesPathOfResultNodePath(startResultNodeName);
			if (getPathResult == null)
			{
				GD.PushError($"获取结果节点{startResultNodeName}至相邻结果节点的节点路径时.该路径为null,因发生错误已跳过");
				continue;
			}
			ResultNodesInformation[startResultNodeName] = (NodesPathOfResultNodePath)getPathResult;
		}
		foreach (string resultNodeName in ResultNodesInformation.Keys)//将每个结果节点数据设置于全局的数据库中
		{
			Dictionary<string,Dictionary<string,ushort>> resultNodePath = FindResultNodeToOther(resultNodeName);
			if (resultNodePath == null)
			{
				GD.PushError($"获取结果节点{resultNodeName}其值为null,因发生错误已跳过");
				continue;
			}
			ResultNodesToOtherPaths[resultNodeName]=resultNodePath;
		}
		VisualizePaths(ResultNodesToOtherPaths);
	}



	/// <summary>
	/// 读取并初始化区块状态节点信息
	/// 即读取<see cref="MachineNodesFilePath"/>路径上的配置文件并将该信息设置于<see cref="BlockLoadNodesInformation"/>中
	/// 为<see cref="ResultNodesInformation"/>注册结果节点的节点名作为键,值为空路径实例
	/// </summary>
	/// <returns>表示初始化是否成功</returns>
	static public bool InitializeNodesInformation()
	{
		if (File.Exists(MachineNodesFilePath) == false)
		{
			GD.PushWarning($"读取BlockStatesManchineNodes.json文件失败,无法读取区块加载状态机相关设置,正确路径: {MachineNodesFilePath}");
			return false;
		}
		string readText = File.ReadAllText(MachineNodesFilePath);
		if (readText == "")
		{
			GD.PushWarning($"读取BlockStatesManchineNodes.json文件错误,区块加载状态机相关设置为空字符串,请维护文件,路径: {MachineNodesFilePath}");
			return false;
		}
		JObject config = JObject.Parse(readText);//解析后得到的对象
		BlockLoadNodesInformation = [];//将区块状态节点信息初始化为空集合
		ResultNodesInformation = [];//将结果节点信息初始化为空集合
		ResultNodesToOtherPaths = [];
		foreach (JProperty NodeProperty in config.Properties())//用Properties()方法获取节点名称数组以遍历所有节点
		{
			//声明该节点的属性信息,并检测元素数量是否正确
			string nodeName = NodeProperty.Name;
			JArray nodeData = (JArray)config[nodeName];
			if (nodeData.Count != (int)NodePriorityIndex.Size)
			{
				GD.PushWarning($"节点{nodeName}的信息作为数组,其元素数量不为规定的{nodeData.Count}个,故属性无法匹配上,请检查该节点,路径: {MachineNodesFilePath}");
				continue;
			}
			//获取所导向的节点的名称数组
			if (nodeData[(int)NodePriorityIndex.OrientedNodesMap].GetType() != typeof(JArray))
			{
				GD.PushWarning($"节点{nodeName}的OrientedNodesMap属性错误,其请检查该节点的OrientedNodesMap属性,路径: {MachineNodesFilePath}");
				continue;
			}
			List<string> OrientedNodesNamesList = ((JArray)nodeData[(int)NodePriorityIndex.OrientedNodesMap]).Select(token => token.ToString()).ToList();
			foreach (JValue orientedNodeValue in (JArray)nodeData[(int)NodePriorityIndex.OrientedNodesMap])
			{
				string orientedNodeName = orientedNodeValue.ToString();
				OrientedNodesNamesList.Add(orientedNodeName);
			}
			//获取NodePrioritys即节点优先度属性
			if (nodeData[(int)NodePriorityIndex.NodePriority].Type != JTokenType.Integer)
			{
				GD.PushWarning($"节点{nodeName}的 NodePriority 属性错误,请检查该节点的 NodePriority 属性,路径: {MachineNodesFilePath}");
				continue;
			}
			int nodePriorityValue = (int)nodeData[(int)NodePriorityIndex.NodePriority];
			//获取OrientedMethodCode即导向方法代码
			if (nodeData[(int)NodePriorityIndex.OrientedMethodCode].Type != JTokenType.String)
			{
				GD.PushWarning($"节点{nodeName}的 OrientedMethodCode 属性错误,请检查该节点的 OrientedMethodCode 属性,路径: {MachineNodesFilePath}");
				continue;
			}
			string orientedMethodCode = (string)nodeData[(int)NodePriorityIndex.OrientedMethodCode];
			//获取IsResultNode即表示其是否为结果节点的标志
			if (nodeData[(int)NodePriorityIndex.IsResultNode].Type != JTokenType.Boolean)
			{
				GD.PushWarning($"节点{nodeName}的 ResultNodePriority 属性错误,请检查该节点的 ResultNodePriority 属性,路径: {MachineNodesFilePath}");
				continue;
			}
			bool isResultNode = (bool)nodeData[(int)NodePriorityIndex.IsResultNode];
			//获取NodeIntroduce即是否为节点介绍文本
			if (nodeData[(int)NodePriorityIndex.NodeIntroduce].Type != JTokenType.String)
			{
				GD.PushWarning($"节点{nodeName}的 NodeIntroduce 属性错误,请检查该节点的 NodeIntroduce 属性,路径: {MachineNodesFilePath}");
				continue;
			}
			string nodeIntroduceText = (string)nodeData[(int)NodePriorityIndex.NodeIntroduce];
			//储存该节点的信息
			BlockStatesNodeInfo nodeInfo = new(OrientedNodesNamesList, nodePriorityValue, orientedMethodCode, isResultNode, nodeIntroduceText);
			BlockLoadNodesInformation[nodeName] = nodeInfo;
			if (isResultNode == true)//若为结果节点则注册其信息
				ResultNodesInformation[nodeName] = new();
		}
		return true;
	}


	/// <summary>
	/// 使用广度优先算法,获取一个结果节点到相邻结果节点所经过的节点组成的路径
	/// 根据<see cref="ResultNodesInformation"/>的键判断路径上的节点是否为结果节点,
	/// 因此使用前应当初始化<see cref="ResultNodesInformation"/>的键.
	/// </summary>
	/// <param name="startResultNodeName">起始的结果节点</param>
	/// <returns></returns>
	static public NodesPathOfResultNodePath? FindNodesPathOfResultNodePath(string startResultNodeName)
	{
		//储存该路径上所有的节点
		HashSet<string> allNodesInPath = GetNodeInfo(startResultNodeName)?.OrientedNodesMap;
		if (allNodesInPath == null)//若节点不存在则进行错误处理 
		{
			GD.PushError($"决定遍历的{startResultNodeName}结果节点不存在,请检查路径: {MachineNodesFilePath}上的配置文件");
			return null;
		}
		//存储目前这条路径上所有节点的名称,默认值为获取结果节点所导向的节点
		List<string> pathOfNodesNames = allNodesInPath.ToList<string>();
		//储存在路径上前一个节点的索引,索引与pathOfNodesNames对应,默认值为指定大小且值皆为-1的列表,-1代表起始的结果节点
		List<ushort> pathOfNodesParentIndex = [.. Enumerable.Repeat(ushort.MaxValue, pathOfNodesNames.Count)];
		//储存结果节点的索引
		List<ushort> orientedResultNodesIndexs = [];
		//在进入新一轮添置新节点的遍历时,为该次遍历的首个元素的索引
		ushort startingTraversalIndex = ushort.MaxValue;
		//为新一次遍历前的路径大小
		ushort oldNodesPathSize = 0;
		//广度优先遍历路径
		while (startingTraversalIndex != oldNodesPathSize)
		{
			startingTraversalIndex = oldNodesPathSize;
			oldNodesPathSize = (ushort)pathOfNodesNames.Count;
			//对上一次遍历的节点进行遍历获取它们导向的新节点们    
			for (ushort newNodeIndex = startingTraversalIndex; newNodeIndex < pathOfNodesNames.Count; newNodeIndex++)
			{
				//新遍历的节点的名称
				string newNodeName = pathOfNodesNames[newNodeIndex];
				//新遍历的节点所导向的节点名称的列表
				HashSet<string> newNodeOrientations = GetNodeInfo(newNodeName)?.OrientedNodesMap;
				if (newNodeOrientations == null)//若该节点不存在,则进行错误处理
				{
					string parentName = pathOfNodesParentIndex[newNodeIndex] == ushort.MaxValue ? startResultNodeName : pathOfNodesNames[pathOfNodesParentIndex[newNodeIndex]];
					GD.PushError($"在遍历结果节点{startResultNodeName}所导向的路径时,其中路径上的{parentName}所导向的节点{newNodeName}不存在");
					continue;
				}
				allNodesInPath.Add(newNodeName);
				if (ResultNodesInformation.ContainsKey(newNodeName))//遍历到为目标的结果节点(即一处路径截止节点),则终止其路径推演
				{
					orientedResultNodesIndexs.Add(newNodeIndex);
					  //orientedResultNodesNames.Add(newNodeName);
					continue;
				}
				pathOfNodesNames.AddRange(newNodeOrientations);
				pathOfNodesParentIndex.AddRange([.. Enumerable.Repeat(newNodeIndex, newNodeOrientations.Count)]);
			}
		}
		//储存路径上的目标结果节点的所有索引
		Dictionary<string, List<ushort>> targetResultNodesIndexs = [];
		//储存通向目标节点的路径上的索引
		Dictionary<string, HashSet<ushort>> indexsToTargetResultNodes = [];
		//通向的目标结果节点的索引
		foreach (ushort targetResultNodeIndex in orientedResultNodesIndexs)//根据orientedResultNodesIndexs初始化targetResultNodesIndexs,根据pathOfNodesParentIndex初始化
		{
			//通向的目标结果节点的名称     
			string targetResultNodeName = pathOfNodesNames[targetResultNodeIndex];
			//存储通向的目标结果节点的所有索引的哈希表
			HashSet<ushort> indexsToTheTargetResultNode = [];
			indexsToTargetResultNodes[targetResultNodeName] = [];
			if (targetResultNodesIndexs.ContainsKey(targetResultNodeName) == false)
				targetResultNodesIndexs[targetResultNodeName] = [];
			targetResultNodesIndexs[targetResultNodeName].Add(targetResultNodeIndex);
			ushort indexToTargetResultNode = targetResultNodeIndex;
			while(true)
			{
				indexsToTargetResultNodes[targetResultNodeName].Add(indexToTargetResultNode);
				if (indexToTargetResultNode == ushort.MaxValue)
					break;
				indexToTargetResultNode = pathOfNodesParentIndex[indexToTargetResultNode];
			}
		}
		return new(startResultNodeName, targetResultNodesIndexs, indexsToTargetResultNodes);
	}


	/// <summary>
	/// 使用深度优先算法,获取一个起始的结果节点到其他结果节点所经过的结果节点组成的路径
	/// </summary>
	/// <param name="startResultNodeName"></param>
	/// <returns>返回一个字典</returns>
	static public Dictionary<string,Dictionary<string,ushort>> FindResultNodeToOther(string startResultNodeName)
	{
		if (ResultNodesInformation.Count == 0)
		{
			GD.PushWarning("在初始化结果节点之间的路径时发生错误,原因是ResultNodesInformation为空");
			return null;
		}
		if (ResultNodesInformation.ContainsKey(startResultNodeName)==false)
		{
			GD.PushWarning($"在初始化结果节点之间的路径时发生错误,原因是ResultNodesInformation中不存在作为起始结果节点的{startResultNodeName}");
			return null;
		}
		//每个索引储存正在进入的结果节点的名称
		List<string> enteringTargetResultNodesNamesList = [startResultNodeName];
		//每个索引代表着一个正在进入的结果节点,基于0 ~ (size-1)的顺序访问当前结果节点所导向的结果节点的列表.元素中的ushort值代表当前结果节点在导向列表中已访问的索引为小于该值的自然数的集合,也就是ORNL已访问的索引在值之前且不包括值.本数组基于顺序访问的特点用ushort值指示导向列表已被访问的结果节点.
		List<ushort> enteringTargetResultNodesIndexs = [ushort.MaxValue];
		//以哈希表记录正在进入的结果节点的名称
		HashSet<string> enteringTargetResultNodesNamesMap = [startResultNodeName];
		//
		Dictionary<string,Dictionary<string,ushort>> AllPaths = [];
		while (true)
		{
			GD.Print(string.Join(",",enteringTargetResultNodesNamesList));
			//目前跟踪的目标结果节点的名称,在此刻未被操作过
			string targetResultNodeName = enteringTargetResultNodesNamesList[^1];
			//目前跟踪的目标结果节点导向的结果节点列表
			List<string> orientedTargetResultNodesNamesList = GetResultNodePathInfo(targetResultNodeName)?.TargetResultNodesNamesList;
			if (orientedTargetResultNodesNamesList == null)//若导向的列表为null即发生错误则报错并结束
			{
				string orientedTargetResultNodesNullInfo = (orientedTargetResultNodesNamesList == null) ? "列表为null" : "列表不为null";
				GD.PushWarning($"在获取<{startResultNodeName}>结果节点导向的结果节点之间的路径时,获取<{targetResultNodeName}>结果节点导向的结果节点的列表时发生了错误,此时{orientedTargetResultNodesNullInfo}");
				break;
			}
			//目前跟踪的目标结果节点的索引,在此刻未被操作过
			ushort targetResultNodeIndex = ++enteringTargetResultNodesIndexs[^1];//将上一次访问的结果节点设置为被访问过
			//代表可用的导向结果节点是否为空(不存在)
			bool isUsableOrientationEmpty=true;
			//筛选的导向的结果节点的名称
			string orientedTargetResultNodeName = null; 
			for (ushort orientedResultNodeIndex = targetResultNodeIndex; orientedResultNodeIndex < orientedTargetResultNodesNamesList.Count; orientedResultNodeIndex++)
			{
				orientedTargetResultNodeName = orientedTargetResultNodesNamesList[orientedResultNodeIndex];
				if (enteringTargetResultNodesNamesMap.Contains(orientedTargetResultNodeName) == false)
				{
					isUsableOrientationEmpty=false;
					targetResultNodeIndex=orientedResultNodeIndex;
					break;
				}
			}
			if (isUsableOrientationEmpty == true)//当无可用的导向的结果节点
			{
				enteringTargetResultNodesNamesMap.Remove(enteringTargetResultNodesNamesList.Last());
				enteringTargetResultNodesNamesList.RemoveAt(enteringTargetResultNodesNamesList.Count - 1);
				enteringTargetResultNodesIndexs.RemoveAt(enteringTargetResultNodesIndexs.Count - 1);
				if (targetResultNodeName == startResultNodeName)
					break;
				continue; 
			}
			enteringTargetResultNodesIndexs[^1]=targetResultNodeIndex;//更新当前结果节点的导向的节点的索引
			//将新的节点相关信息加入历史列表中
			enteringTargetResultNodesIndexs.Add(ushort.MaxValue);
			enteringTargetResultNodesNamesList.Add(orientedTargetResultNodeName);
			enteringTargetResultNodesNamesMap.Add(orientedTargetResultNodeName);
			if (AllPaths.ContainsKey(orientedTargetResultNodeName)==false)
				AllPaths[orientedTargetResultNodeName]=[];
			for (ushort enteringTargetResultNodeIndex = 0;enteringTargetResultNodeIndex<enteringTargetResultNodesNamesList.Count;enteringTargetResultNodeIndex++)
			{
				string enteringTargetResultNodeName = enteringTargetResultNodesNamesList[enteringTargetResultNodeIndex];
				ushort enteringTargetResultNodeDistance = (ushort)(enteringTargetResultNodesNamesList.Count-enteringTargetResultNodeIndex);
				if (AllPaths[orientedTargetResultNodeName].ContainsKey(enteringTargetResultNodeName)==false||
				AllPaths[orientedTargetResultNodeName][enteringTargetResultNodeName]>enteringTargetResultNodeDistance)
					AllPaths[orientedTargetResultNodeName][enteringTargetResultNodeName]=enteringTargetResultNodeDistance;
			}
		}
		return AllPaths;
	}





	/// <summary>
	/// 可视化输出 GetResultNodesToOtherPaths() 的结果，便于调试或日志查看  (ai编写)
	/// </summary>
	/// <param name="allPath">由 GetResultNodesToOtherPaths 返回的路径字典</param>
	static public void VisualizePaths(Dictionary<string, Dictionary<string,Dictionary<string,ushort>>> allPath)
	{
		if (allPath == null || allPath.Count == 0)
		{
			GD.Print("路径字典为空。");
		return;
		}

		foreach (var startNode in allPath)
		{
			string startName = startNode.Key;
			GD.Print($"\n从结果节点 \"{startName}\" 出发的路径：");

			var targets = startNode.Value;
			if (targets.Count == 0)
			{
			GD.Print("  → 无可达目标结果节点。");
			continue;
			}

			foreach (var target in targets)
			{
			string targetName = target.Key;
			Dictionary<string,ushort> intermediateNodes = target.Value;
			GD.Print($"  → 到达 \"{targetName}\" 的路径中经过的节点集合：");
			GD.Print("节点数量 "+intermediateNodes.Count.ToString()+" | "+$"{string.Join(", ",intermediateNodes)}");
			}
		}
	}

	
	/*******************************
				节点变更
	********************************/


	/// <summary>
	/// 默认的初始节点名称
	/// </summary>
	const string DefaultStartNodeName = "enter";

	/// <summary>
	/// 当前选中的节点
	/// </summary>
	private string SelectedNodeName { get; set; } = null;

	/// <summary>
	/// 目前所在的结果节点
	/// </summary>
	private string NowResultNodeName { get; set; } = null;

	/// <summary>
	/// 目标的结果节点
	/// </summary>
	private string TargetResultNodeName { get; set; } = null;

	/// <summary>
	/// 变更选中的节点
	/// </summary>
	/// <returns></returns>
	public bool ChangeSelectedNode()
	{
		//选中节点特殊情况与错误检测与处理
		if (BlockLoadNodesInformation.ContainsKey(SelectedNodeName) == false)
		{
			if (SelectedNodeName == null||SelectedNodeName == "")
			{
				GD.PushError($"在变更节点时,当前选中的节点为{SelectedNodeName}即空或错误,已当作默认初始节点处理");
				SelectedNodeName=DefaultStartNodeName;
			}
			else
			{
				GD.PushError($"在变更节点时,当前选中的节点{SelectedNodeName}不存在");
				return false;
			}
		}
		//特殊选中节点的处理
		if (SelectedNodeName == "enter")
		{
			SelectedNodeName="not_in_memory";
			NowResultNodeName="not_in_memory";
		}
		if (SelectedNodeName == "exit")
			return false;
		//目前与目标 结果节点 特殊情况与错误检测与处理
		if (ResultNodesInformation.ContainsKey(NowResultNodeName) == false)
		{
			if (NowResultNodeName == null || NowResultNodeName == "")
			{
				GD.PushError($"在变更节点时,当前结果节点为{NowResultNodeName}值即空或错误");
				return false;
			}
			else
			{
				GD.PushError($"在变更节点时,目前的结果节点{NowResultNodeName}不存在");
				return false;
			}
		}
		if (ResultNodesInformation.ContainsKey(TargetResultNodeName) == false)
		{
			if (TargetResultNodeName == null || TargetResultNodeName == "")
			{
				GD.PushError($"在变更节点时,目标结果节点为{TargetResultNodeName}值即空或错误");
				return false;
			}
			else
			{
				GD.PushError($"在变更节点时,设定的目标结果节点{TargetResultNodeName}不存在");
				return false;
			}
		}
		//变更逻辑

		//在当前结果节点到目标结果节点的路径上的所有节点
		Dictionary<string,ushort> pathNodesNames=GetResultNodeToAnotherPath(NowResultNodeName,TargetResultNodeName);
		//当前节点导向的所有节点
		List<string> selectedNodeOrientedNodesList = ((BlockStatesNodeInfo)GetNodeInfo(SelectedNodeName)).OrientedNodesList;
		//迭代的节点名称
		string iterationNodeName = null;
		//迭代的节点优先度
		int iterationNodePriority = 77;
		foreach (string orientedNodeName in selectedNodeOrientedNodesList)
		{
			if (pathNodesNames.ContainsKey(orientedNodeName)==false)
				continue;
			int orientedNodePriority = ((BlockStatesNodeInfo)GetNodeInfo(orientedNodeName)).NodePriority;
			if (iterationNodeName == null||orientedNodePriority>iterationNodePriority)
			{
				iterationNodeName = orientedNodeName;
				iterationNodePriority = orientedNodePriority;
				continue;
			}
		}
		if (iterationNodeName == null)
		{
			return false;
		}
		SelectedNodeName = iterationNodeName;
		if (ResultNodesInformation.ContainsKey(iterationNodeName))
			NowResultNodeName = iterationNodeName;
		return true;
	}


	/// <summary>
	/// 是否到达目标结果节点
	/// </summary>
	/// <returns></returns>
	bool IsArrivedTargetResultNode()
	{
		if (NowResultNodeName == TargetResultNodeName)
		{
			return true;
		}
		return false;
	}



	/*******************************
				通用设计
	********************************/

	public BlockLoadStatesMachine()
	{
		SelectedNodeName=DefaultStartNodeName;
	}


	public BlockLoadStatesMachine(string startNodeName=DefaultStartNodeName)
	{
		SelectedNodeName=startNodeName;
	}


}


/// <summary>
/// 储存一个状态节点的基本信息
/// </summary>
public struct BlockStatesNodeInfo
{

	/// <summary>
	/// 储存导向的节点的列表
	/// </summary>
	public List<String> OrientedNodesList { get; set; } = [];


	/// <summary>
	/// 储存导向的节点的表
	/// </summary>
	public HashSet<String> OrientedNodesMap { get; set; } = [];

	public int NodePriority { get; set; } = 0;

	public string OrientedMethodCode { get; set; } = "";

	public bool IsResultNode { get; set; } = false;

	public string NodeIntroduce { get; set; } = "";



	public BlockStatesNodeInfo(
		List<String> OrientedNodesList,
		int nodePriority,
		string orientedMethodCode,
		bool isResultNode,
		string nodeIntroduce)
	{
		this.OrientedNodesList = OrientedNodesList;
		this.OrientedNodesMap = [.. OrientedNodesList];
		this.NodePriority = nodePriority;
		this.OrientedMethodCode = orientedMethodCode;
		this.IsResultNode = isResultNode;
		this.NodeIntroduce = nodeIntroduce;
	}



}



/// <summary>
/// 结果节点与邻接结果节点所经过的节点组成的路径
/// </summary>
public struct NodesPathOfResultNodePath
{

	/// <summary>
	/// 起始的结果节点
	/// </summary>
	public string StartNodeName = null;

	/// <summary>
	/// 路径上的目标结果节点的所有名称及索引
	/// </summary>
	public Dictionary<string, List<ushort>> OrientedResultNodesNamesAndIndexs = null;

	/// <summary>
	/// 储存通向目标结果节点的路径上的节点的索引
	/// </summary>
	public Dictionary<string, HashSet<ushort>> IndexsToTargetResultNodes = null;

	/// <summary>
	/// 通向的目标结果节点的所有名称的表
	/// </summary>
	public HashSet<string> TargetResultNodesNamesMap = null;

	/// <summary>
	/// 通向的目标结果节点的所有名称的列表
	/// </summary>
	public List<string> TargetResultNodesNamesList = null;

	/// <summary>
	/// 是否可以被使用
	/// </summary>
	private bool isUsable = false;

	/// <summary>
	/// 创建可有正常值的路径实例
	/// </summary>
	/// <param name="pathOfNodesNames"></param>
	/// <param name="allNodesInPath"></param>
	/// <param name="pathOfNodesParentIndex"></param>
	/// <param name="targetResultNodesInfo"></param>
	public NodesPathOfResultNodePath(
	string startNodeName,
	Dictionary<string, List<ushort>> orientedResultNodesNamesAndIndexs,
	Dictionary<string, HashSet<ushort>> indexsToTargetResultNodes)
	{
		if (startNodeName == null)
		{
			GD.PushWarning("创建ResultNodePath实例时发生了错误,所赋予的startNodeName属性为null");
			return;
		}
		if (orientedResultNodesNamesAndIndexs == null)
		{
			GD.PushWarning("创建ResultNodePath实例时发生了错误,所赋予的orientedResultNodesNamesAndIndexs属性为null");
			return;
		}
		if (indexsToTargetResultNodes == null)
		{
			GD.PushWarning("创建ResultNodePath实例时发生了错误,所赋予的indexsToTargetResultNodes属性为null");
			return;
		}
		if (orientedResultNodesNamesAndIndexs.Count==0)
		{
			GD.PushWarning("创建ResultNodePath实例时发生了错误,所赋予的orientedResultNodesNamesAndIndexs属性为空");
			return;
		}
		if (indexsToTargetResultNodes.Count==0)
		{
			GD.PushWarning("创建ResultNodePath实例时发生了错误,所赋予的indexsToTargetResultNodes属性为空");
			return;
		}
		StartNodeName=startNodeName;
		OrientedResultNodesNamesAndIndexs=orientedResultNodesNamesAndIndexs;
		IndexsToTargetResultNodes=indexsToTargetResultNodes;
		TargetResultNodesNamesMap=[.. OrientedResultNodesNamesAndIndexs.Keys];
		TargetResultNodesNamesList=[.. OrientedResultNodesNamesAndIndexs.Keys];
		isUsable=true;
	}

	/// <summary>
	/// 判断该实例是否是可用的
	/// </summary>
	public bool CanUse()
	{
		return isUsable;
	}

}
